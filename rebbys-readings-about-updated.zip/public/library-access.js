(function(){document.documentElement.classList.add('library-open');window.libraryAccess={unlocked:true,unlock(){window.dispatchEvent(new Event('library-unlocked'));}};})();
