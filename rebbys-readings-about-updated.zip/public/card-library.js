(function () {
  const search = document.querySelector('#cardSearch');
  const category = document.querySelector('#cardCategory');
  const cards = [...document.querySelectorAll('#meaningsGrid .meaning-card')];
  if (!search || !category || !cards.length) return;
  document.querySelector('.library-search').hidden = false;
  const index = cards.map(card => ({ card, text: card.textContent.toLocaleLowerCase('en-GB') }));
  function filterCards() {
    const query=search.value.trim().toLocaleLowerCase('en-GB');
    const words = query.split(/\s+/).filter(Boolean);
    const exact=index.find(({card})=>card.querySelector('h3').textContent.toLocaleLowerCase('en-GB')===query);
    let count = 0;
    index.forEach(({ card, text }) => {
      const matches = (category.value === 'all' || card.dataset.category === category.value) && (exact ? card===exact.card : words.every(word => text.includes(word)));
      card.hidden = !matches;
      if (matches) count++;
    });
    document.querySelector('#cardSearchCount').textContent = count
      ? count + (count === 1 ? ' card found' : ' cards found')
      : 'No cards match. Try a different word or choose all cards.';
  }
  search.addEventListener('input', filterCards);
  category.addEventListener('change', filterCards);
})();
