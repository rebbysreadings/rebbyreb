// Confirmation emails return to the site's home page by default.
if (/^#(?:confirmation_token|recovery_token|invite_token|email_change_token)=/.test(window.location.hash)) {
  window.location.replace('/free-resources/' + window.location.hash);
}
