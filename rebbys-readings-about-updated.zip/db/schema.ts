import { pgTable, text, integer, jsonb, timestamp, boolean } from 'drizzle-orm/pg-core';
export const orders = pgTable('orders', {
  reference: text('reference').primaryKey(),
  token: text('token').notNull().unique(),
  name: text('name').notNull(),
  email: text('email').notNull(),
  items: jsonb('items').notNull(),
  extras: jsonb('extras').notNull(),
  amount: integer('amount').notNull(),
  status: text('status').notNull().default('awaiting_payment'),
  session: text('stripe_session').unique(),
  testMode: boolean('test_mode').notNull().default(false),
  createdAt: timestamp('created_at', {withTimezone:true}).defaultNow().notNull(),
});
