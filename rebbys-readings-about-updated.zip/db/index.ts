import { drizzle } from 'drizzle-orm/netlify-db';
import * as schema from './schema.ts';
export function database() { return drizzle({ schema }); }
