# AGENTS.md

## Architecture
- This is a static site with no build step. Netlify publishes `public/` (set in `netlify.toml`).
- `public/index.html` holds the whole single-page site: inline `<style>`, the markup, and one inline `<script>` IIFE at the bottom.
- `public/tarot-cards.js` sets `window.TAROT_CARDS`, with 78 entries of `{slug, name, arcana, num, keys, up, rev}`. Each card's image is `public/cards/<slug>.jpg`.
- Netlify Forms are detected from the static HTML: `booking` and `meanings-list`. Both submit by AJAX POST to `/`. Any new field must also exist in the static HTML, or Netlify drops it. The `.netlify/features/netlify-forms` marker turns on form detection.
- The booking basket lives only in memory. It is serialised as JSON into the hidden `basket_items` field on submit.
- Payment is a PayPal.Me link (`paypal.me/rebbysreadings/<total>`). Nothing confirms payment automatically; Rebby matches payments to booking references by hand.

## Conventions
- Reference images through the Image CDN (`/.netlify/images?url=/path&w=<width>&fm=webp`) rather than linking the originals.
- Build DOM from JavaScript with `textContent`, not `innerHTML`, whenever user input is involved.
- Copy is British English. Prices appear in three places: the menu cards, the `<option data-price>` values, and the extras checkboxes. Keep all three in sync.
- The card-meanings "lock" is a marketing gate on the client only, because the full data is public in `tarot-cards.js`. Don't treat it as access control.
