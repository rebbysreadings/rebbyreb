CREATE TABLE "orders" (
	"reference" text PRIMARY KEY,
	"token" text NOT NULL UNIQUE,
	"name" text NOT NULL,
	"email" text NOT NULL,
	"items" jsonb NOT NULL,
	"extras" jsonb NOT NULL,
	"amount" integer NOT NULL,
	"status" text DEFAULT 'awaiting_payment' NOT NULL,
	"stripe_session" text UNIQUE,
	"test_mode" boolean DEFAULT false NOT NULL,
	"created_at" timestamp with time zone DEFAULT now() NOT NULL
);
