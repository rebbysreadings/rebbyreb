// Prices in whole pounds. Checkout charges these server-side values, never prices sent by the browser.
// Keep in sync with the menu cards, <option data-price> values and extras checkboxes in public/index.html.
export const SERVICES: Record<string, { name: string; price: number }> = {
  quick: { name: 'Quick Question', price: 15 },
  rebby: { name: 'Reading with Rebby', price: 29 },
  deep: { name: 'The Deep Dive', price: 44 },
  live20: { name: 'Live Mini Session (20 min)', price: 25 },
  live60: { name: 'Live Full Reading (60 min)', price: 65 },
  chart: { name: 'Birth Chart Analysis (PDF)', price: 25 },
  design: { name: 'Human Design Chart Analysis (PDF)', price: 32 },
  pendulum: { name: 'Pendulum Questions (5 Questions)', price: 15 },
  cord: { name: 'Cord Cutting Ritual', price: 25 },
  jar: { name: 'Personalised Spell Jar', price: 18 },
};

export const EXTRAS: Record<string, { name: string; price: number }> = {
  voicenote: { name: 'Voice Note Audio Walkthrough', price: 10 },
  reiki: { name: 'Distance Reiki Healing Session', price: 11 },
  priority: { name: 'Priority Queue Jump', price: 15 },
};
