import { database } from '../../db/index.ts';
import { orders } from '../../db/schema.ts';
import { eq } from 'drizzle-orm';
import type { Config } from '@netlify/functions';
import Stripe from 'stripe';

const json = (body: unknown, status = 200) => Response.json(body, {
  status, headers: { 'Cache-Control': 'no-store' },
});

export default async (req: Request) => {
  const key = Netlify.env.get('STRIPE_SECRET_KEY');
  if (!key) return json({ error: 'Payment verification is temporarily unavailable.' }, 503);
  const id = new URL(req.url).searchParams.get('session_id') || '';
  if (!/^cs_(live|test)_[A-Za-z0-9]{10,250}$/.test(id)) {
    return json({ error: 'Invalid checkout session.' }, 400);
  }
  try {
    const session = await new Stripe(key, { timeout: 15000 }).checkout.sessions.retrieve(id);
    if (!session.client_reference_id?.startsWith('RR-') || session.metadata?.booking_reference !== session.client_reference_id) {
      return json({ error: 'Booking payment not found.' }, 404);
    }
    const db=database();
    const [order]=await db.select().from(orders).where(eq(orders.session,session.id));
    if(!order || order.reference!==session.client_reference_id || session.currency!=='gbp' || session.amount_total!==order.amount) return json({error:'Booking payment mismatch.'},409);
    // Return only payment state and the booking reference, never customer details.
    return json({ status: order.status==='payment_failed' ? 'failed' : session.payment_status==='paid' && ['paid','test_paid','appointment_confirmed','delivered'].includes(order.status) ? 'paid' : 'pending', reference: session.client_reference_id, testMode: !session.livemode });
  } catch {
    return json({ error: 'Unable to verify payment. Please contact Rebby with your booking reference.' }, 502);
  }
};

export const config: Config = { path: '/api/stripe-status', method: 'GET' };
