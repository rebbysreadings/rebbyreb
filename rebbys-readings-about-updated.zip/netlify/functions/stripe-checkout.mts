import type { Config, Context } from '@netlify/functions';
import Stripe from 'stripe';
import { database } from '../../db/index.ts';
import { orders } from '../../db/schema.ts';
import { and, eq } from 'drizzle-orm';

const json = (body: unknown, status = 200) => Response.json(body, { status, headers: { 'Cache-Control': 'no-store' } });

export default async (req: Request, context: Context) => {
  const key = Netlify.env.get('STRIPE_SECRET_KEY');
  if(context?.deploy?.context==='deploy-preview' && key && !/^(sk|rk)_test_/.test(key)) return json({enabled:false,error:'Test-mode Stripe credentials are required for previews.'},503);
  // Confirm credentials with Stripe rather than trusting a key-shaped string.
  if (req.method === 'GET') {
    if (!key || !Netlify.env.get('STRIPE_WEBHOOK_SECRET')) return json({ enabled: false });
    try {
      // Restricted keys may permit Checkout while denying account details.
      await new Stripe(key, { timeout: 15000 }).checkout.sessions.list({ limit: 1 });
      return json({ enabled: true, testMode: /^(sk|rk)_test_/.test(key) });
    } catch (err) {
      console.error('Stripe checkout availability check failed', err instanceof Stripe.errors.StripeError ? { type: err.type, code: err.code } : { type: 'unknown' });
      return json({ enabled: false });
    }
  }
  if (req.method !== 'POST') return json({ error: 'Method not allowed' }, 405);
  if (!key || !Netlify.env.get('STRIPE_WEBHOOK_SECRET')) return json({ error: 'Card payments are not available yet. Please use PayPal below.' }, 503);
  if(req.headers.get('origin')!==new URL(req.url).origin) return json({error:'Invalid origin'},403);

  let input: any;
  try { input = await req.json(); } catch { return json({ error: 'Invalid request' }, 400); }

  try {
  const db = database();
  const [order] = await db.select().from(orders).where(eq(orders.token, String(input.token || '')));
  if (!order || order.reference !== input.reference) return json({error:'Booking not found. Please submit your details first.'},404);
  if (!['awaiting_payment','stripe_started'].includes(order.status)) return json({error:'A payment has already been started or recorded for this booking. Contact Rebby before paying again.'},409);
  if(order.status==='awaiting_payment'){const claimed=await db.update(orders).set({status:'stripe_started'}).where(and(eq(orders.reference,order.reference),eq(orders.status,'awaiting_payment'))).returning();if(!claimed.length)return json({error:'A payment is already being started. Please reload your saved booking.'},409);}
  const reference = order.reference, email = order.email, name = order.name;
  const line_items: Stripe.Checkout.SessionCreateParams.LineItem[] = [{quantity:1,price_data:{currency:'gbp',unit_amount:order.amount,product_data:{name:`Rebby's Readings · ${reference}`}}}];
  const origin = new URL(req.url).origin;
  const stripe = new Stripe(key, { maxNetworkRetries: 2, timeout: 15000 });
  try {
    let attempt=reference;
    if (order.session) {
      const previous = await stripe.checkout.sessions.retrieve(order.session);
      if(previous.status === 'open' && previous.url) return json({url:previous.url});
      if(previous.status!=='expired' || previous.payment_status==='paid') return json({error:'Payment may already be processing. Please contact Rebby before starting another payment.'},409);
      attempt=reference+'-'+previous.id;
    }
    const session = await stripe.checkout.sessions.create({
      mode: 'payment',
      line_items,

      client_reference_id: reference,
      customer_email: /^[^\s@]+@[^\s@]+\.[^\s@]+$/.test(email) ? email : undefined,
      metadata: { booking_reference: reference, client_name: name },
      payment_intent_data: { description: `Rebby's Readings booking ${reference}`, metadata: { booking_reference: reference, client_name: name } },
      success_url: `${origin}/?checkout=success&session_id={CHECKOUT_SESSION_ID}#book`,
      cancel_url: `${origin}/?checkout=cancelled&ref=${encodeURIComponent(reference)}#book`,
    }, {idempotencyKey: `booking-${attempt}`});
    await db.update(orders).set({session:session.id,testMode:!session.livemode}).where(eq(orders.reference,reference));
    if (!session.url) return json({ error: 'Could not start card payment. Please try again.' }, 502);
    return json({ url: session.url });
  } catch (err) {
    console.error('Stripe checkout request failed', err instanceof Stripe.errors.StripeError ? { type: err.type, code: err.code } : { type: 'unknown' });
    return json({ error: 'Could not start card payment. Please try again.' }, 502);
  }
  } catch { return json({error:'Checkout is temporarily unavailable. No new payment has been started.'},503); }
};

export const config: Config = { path: '/api/stripe-checkout', method: ['GET', 'POST'] };
