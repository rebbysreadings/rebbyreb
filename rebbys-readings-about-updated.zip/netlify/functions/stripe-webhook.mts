import Stripe from 'stripe';
import { and, eq, inArray } from 'drizzle-orm';
import { database } from '../../db/index.ts';
import { orders } from '../../db/schema.ts';
export default async (req: Request) => {
  if(req.method!=='POST') return new Response('Method not allowed',{status:405});
  const key=Netlify.env.get('STRIPE_SECRET_KEY'), secret=Netlify.env.get('STRIPE_WEBHOOK_SECRET');
  if(!key||!secret) return new Response('Webhook not configured',{status:503});
  let event: Stripe.Event;
  try { event=await new Stripe(key).webhooks.constructEventAsync(await req.text(),req.headers.get('stripe-signature')||'',secret); }
  catch { return new Response('Invalid signature',{status:400}); }
  try {
    if(['checkout.session.completed','checkout.session.async_payment_succeeded'].includes(event.type)) {
      const session=event.data.object as Stripe.Checkout.Session;
      if(session.payment_status==='paid' && session.currency==='gbp') {
        const db=database();
        const [order]=await db.select().from(orders).where(eq(orders.session,session.id));
        if(!order || order.amount!==session.amount_total || order.reference!==session.client_reference_id) return new Response('Order mismatch',{status:409});
        await db.update(orders).set({status:session.livemode?'paid':'test_paid',testMode:!session.livemode}).where(and(eq(orders.reference,order.reference),inArray(orders.status,['awaiting_payment','stripe_started','payment_failed'])));
      }
    }
    if(event.type==='checkout.session.async_payment_failed') {
      const session=event.data.object as Stripe.Checkout.Session;
      const db=database();const [order]=await db.select().from(orders).where(eq(orders.session,session.id));
      if(!order || session.currency!=='gbp' || order.amount!==session.amount_total || order.reference!==session.client_reference_id)return new Response('Order mismatch',{status:409});
      await db.update(orders).set({status:'payment_failed'}).where(and(eq(orders.reference,order.reference),inArray(orders.status,['awaiting_payment','stripe_started'])));
    }
    return new Response('Received');
  } catch { return new Response('Please retry',{status:503}); }
};
export const config={path:'/api/stripe-webhook'};
