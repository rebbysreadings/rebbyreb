import { database } from '../../db/index.ts';
import { orders } from '../../db/schema.ts';
import { SERVICES, EXTRAS } from '../lib/catalog.ts';
import { and, eq, isNull } from 'drizzle-orm';
import { isDeepStrictEqual } from 'node:util';
export default async (req: Request) => {
  const json = (body: unknown, status=200) => Response.json(body,{status,headers:{'Cache-Control':'no-store'}});
  if(req.method==='GET') {
    const token=req.headers.get('X-Booking-Token')||'';
    if(!/^[a-f0-9-]{36}$/.test(token)) return json({error:'Invalid booking request'},400);
    try { const [order]=await database().select().from(orders).where(eq(orders.token,token));
      if(!order) return json({error:'Booking not found'},404);
      return json({reference:order.reference,name:order.name,email:order.email,items:order.items,extras:order.extras,amount:order.amount,status:order.status});
    } catch { return json({error:'Unable to recover booking. Please contact Rebby before paying again.'},503); }
  }
  if(req.method!=='POST') return json({error:'Method not allowed'},405);
  if(req.headers.get('origin') !== new URL(req.url).origin) return json({error:'Invalid origin'},403);
  try {
    const input=await req.json();
    if(input.action==='paypal') {
      const token=String(input.token||''); if(!/^[a-f0-9-]{36}$/.test(token)) return json({error:'Invalid booking request'},400);
      const db=database();const [order]=await db.update(orders).set({status:'awaiting_manual'}).where(and(eq(orders.token,token),eq(orders.status,'awaiting_payment'),isNull(orders.session))).returning();
      if(!order)return json({error:'A payment may already be in progress. Contact Rebby before paying again.'},409);
      return json({url:'https://www.paypal.com/paypalme/rebbysreadings/'+(order.amount/100)});
    }
    if(input['bot-field']) return json({error:'Unable to save booking'},400);
    const name=String(input.name||'').trim(), email=String(input.email||'').trim();
    const items=input.items;
    if(!name || name.length>150 || !/^[^\s@]+@[^\s@]+\.[^\s@]+$/.test(email) || email.length>254 || !Array.isArray(items) || items.length<1 || items.length>20) return json({error:'Please check your name, email and service.'},400);
    for (const item of items) {
    const service=Object.hasOwn(SERVICES,item?.service) ? SERVICES[item.service] : null;
    const d=item.details||{};
    if(!service || (!Number.isInteger(item.quantity) || item.quantity<1 || item.quantity>20) || !String(d.questions||'').trim() || JSON.stringify(d).length>12000) return json({error:'Please add your question or focus.'},400);
    const validDate=(value:unknown)=>{if(typeof value!=='string'||!/^\d{4}-\d{2}-\d{2}$/.test(value))return false;const date=new Date(value+'T12:00:00Z');return !isNaN(+date)&&date.toISOString().slice(0,10)===value;};
    if(['chart','design'].includes(item.service)) {
      if(!validDate(d.birth_date) || d.birth_date>new Date().toISOString().slice(0,10) || !d.birth_location || !/^([01]\d|2[0-3]):[0-5]\d$/.test(d.birth_time||'')) return json({error:'Please complete your birth date, time and location. Contact Rebby first if your birth time is unknown.'},400);
    }
    if(item.service==='pendulum' && String(d.questions).trim().split(/\n/).filter(line=>line.trim()).length!==5) return json({error:'Please enter five pendulum questions, one per line.'},400);
    if(item.service==='jar' && !String(d.shipping_address||'').trim()) return json({error:'Please enter your UK postal address.'},400);
    if(item.service.startsWith('live')) {
      const today=new Intl.DateTimeFormat('en-CA',{timeZone:'Europe/London',year:'numeric',month:'2-digit',day:'2-digit'}).format(new Date());
      const match=/^(\d{2}):(\d{2})\s*(am|pm)$/i.exec(d.live_slot||'');
      const date=new Date(d.live_date+'T12:00:00Z');
      if(!match || Number(match[1])<1 || Number(match[1])>12 || Number(match[2])>59 || !validDate(d.live_date) || isNaN(+date) || d.live_date<=today) return json({error:'Choose a preferred appointment from tomorrow onwards.'},400);
      const mins=(Number(match[1])%12+(match[3].toLowerCase()==='pm'?12:0))*60+Number(match[2]);
      const duration=item.service==='live60'?60:20;
      if(mins<540 || mins%20!==0 || mins+duration>([0,6].includes(date.getUTCDay())?1260:840)) return json({error:'Choose a time within the published UK opening hours.'},400);
    }
    if(item.service.startsWith('live') && !['video','phone'].includes(d.live_format)) return json({error:'Please choose Zoom or a UK phone call.'},400);
    }
    items.forEach(item=>{item.price=SERVICES[item.service].price;item.title=SERVICES[item.service].name;});
    const extras=Object.keys(input.extras||{}).filter(id=>input.extras[id]===true);
    if(extras.some(id=>!Object.hasOwn(EXTRAS,id) || ((id==='priority'||id==='voicenote')&&!items.some(item=>['quick','rebby','deep','chart','design','pendulum'].includes(item.service))))) return json({error:'An extra is not available for this service.'},400);
    const token=String(input.token||'');
    if(!/^[a-f0-9-]{36}$/.test(token)) return json({error:'Invalid booking request'},400);
    const db=database();
    const reference='RR-'+crypto.randomUUID().toUpperCase();
    const amount=(items.reduce((sum,item)=>sum+SERVICES[item.service].price*item.quantity,0)+extras.reduce((sum,id)=>sum+EXTRAS[id].price,0))*100;
    await db.insert(orders).values({reference,token,name,email,items,extras,amount}).onConflictDoNothing({target:orders.token});
    const [order]=await db.select().from(orders).where(eq(orders.token,token));
    if(order.name!==name || order.email!==email || order.amount!==amount || !isDeepStrictEqual(order.items,items) || !isDeepStrictEqual(order.extras,extras)) return json({error:'This booking request has already been saved with different details. Contact Rebby before paying or creating another booking.'},409);
    return json({reference:order.reference,amount:order.amount});
  } catch { return json({error:'Your booking could not be saved. No payment has been taken. Please try again or contact Rebby.'},503); }
};
export const config={path:'/api/bookings'};
