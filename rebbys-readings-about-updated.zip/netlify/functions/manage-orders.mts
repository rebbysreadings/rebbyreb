import { timingSafeEqual } from 'node:crypto';
import { database } from '../../db/index.ts';
import { orders } from '../../db/schema.ts';
import { desc, eq } from 'drizzle-orm';
export default async (req: Request) => {
  const json=(body:unknown,status=200)=>Response.json(body,{status,headers:{'Cache-Control':'no-store'}});
  const expected=Netlify.env.get('ORDER_ADMIN_PASSWORD');
  if(!expected) return json({error:'Order management is not configured.'},503);
  const provided=req.headers.get('authorization')?.replace(/^Bearer /,'')||'';
  const a=Buffer.from(provided),b=Buffer.from(expected);
  if(a.length!==b.length || !timingSafeEqual(a,b)) return json({error:'Access denied'},401);
  try {
    const db=database();
    if(req.method==='GET') return json(await db.select({reference:orders.reference,name:orders.name,email:orders.email,items:orders.items,extras:orders.extras,amount:orders.amount,status:orders.status,createdAt:orders.createdAt,testMode:orders.testMode}).from(orders).orderBy(desc(orders.createdAt)).limit(200));
    if(req.method!=='POST')return json({error:'Method not allowed'},405);
    const input=await req.json();
    const [order]=await db.select().from(orders).where(eq(orders.reference,String(input.reference)));
    if(!order)return json({error:'Order not found'},404);
    const allowed:Record<string,string[]>={awaiting_payment:['paid_manual'],awaiting_manual:['paid_manual'],paid:['appointment_confirmed','delivered'],paid_manual:['appointment_confirmed','delivered'],appointment_confirmed:['delivered']};
    if(!allowed[order.status]?.includes(input.status))return json({error:'This status change is not permitted.'},400);
    await db.update(orders).set({status:input.status}).where(eq(orders.reference,order.reference));
    return json({ok:true});
  }catch{return json({error:'Order management is temporarily unavailable'},503);}
};
export const config={path:'/api/manage-orders'};
