# Rebby's Readings

The website for Rebby's Readings: personal tarot, oracle, pendulum, birth chart and Human Design readings, written or live, by Rebby (UK).

Visitors can browse readings and prices, draw a free tarot card, freely explore all 78 card meanings and resource guides, check their Sun sign, and book one or more services with relevant details and optional extras. Newsletter registration is optional. Orders are saved securely before payment. When Stripe is available, customers are sent straight to Stripe Checkout; PayPal remains an alternative requiring manual verification.

## Technology

- One static HTML page (`public/index.html`) with inline CSS and plain JavaScript. There is no build step.
- `public/tarot-cards.js` holds all 78 card names, keywords and meanings.
- `public/cards/` holds the public-domain 1909 Rider-Waite-Smith card scans from Wikimedia Commons.
- **Netlify Database** persists orders, payment state and fulfilment status using the schema in `db/schema.ts` and the migration under `netlify/database/migrations/`.
- **Netlify Functions** validates bookings and totals, creates Stripe Checkout sessions and verifies payment status and signed webhook events.
- **Netlify Forms** handles optional newsletter requests (`circle-signup`). The free library has no signup gate; all card meanings are static HTML, with optional JavaScript search.
- **Netlify Image CDN** (`/.netlify/images`) serves the photos, logo and card scans as resized WebP.

## Running locally

```bash
netlify dev --port 8889
```

Form submissions and `/.netlify/images` URLs only work under `netlify dev` or on a deployed site. Opening the HTML file directly won't run them.

## Payments and fulfilment

Set `STRIPE_SECRET_KEY` for card checkout. Test with a Stripe test account before configuring live payments. Apple Pay appears only where Stripe supports and enables it. Configure `/api/stripe-webhook` in Stripe for `checkout.session.completed` and `checkout.session.async_payment_succeeded`, and `checkout.session.async_payment_failed`, then set the corresponding `STRIPE_WEBHOOK_SECRET` in each deployment context. Never put these values in source or browser code.

PayPal.Me remains a manual payment method. Customers must quote their booking reference in the payment note or send it to Rebby. Rebby must verify the transaction in PayPal before recording a manual paid status. The site never infers PayPal payment from a click or return URL.

The private `/manage/` page requires `ORDER_ADMIN_PASSWORD`. It lists recent orders and records manual payment checks, agreed appointments and delivery. It does not send emails. Passwords and order details are not persisted in browser storage. Until configured, this endpoint fails closed and does not expose orders.

Written delivery is within 7 days of verified payment; priority is within 48–72 hours, subject to availability. Live slots are preferences in Europe/London and require personal confirmation. Business contact details, policies, postage arrangements and data-retention practice need owner review before launch.

## Verification

Run `npm ci` and install Chromium with `npx playwright install chromium`. With the local server on port 8889, run:

```bash
npx tsx tests/server-validation.ts
node tests/customer-journey.mjs
node tests/failure-and-catalogue.mjs
node tests/final-checkout.mjs
node tests/payment-states.mjs
node tests/refinement.mjs
```

Browser tests mock booking and newsletter responses and the unpaid Stripe return. They do not create payments or prove deployed form delivery. Complete database persistence, newsletter delivery and Stripe test-transaction checks after deploying and configuring the required services. No automated customer emails or performance scores are claimed.
