import {chromium} from '@playwright/test';
import assert from 'node:assert/strict';
const browser=await chromium.launch();
const page=await browser.newPage({viewport:{width:390,height:844}});
let order,posts=0,fail=false;
await page.route('**/api/bookings',async route=>{
 if(route.request().method()==='GET')return route.fulfill({json:order});
 posts++;const body=route.request().postDataJSON();
 if(fail)return route.fulfill({status:503,json:{error:'No payment was started. Please retry.'}});
 const prices={quick:15,rebby:29,live20:25,chart:25};
 order={...body,reference:'RR-LOCAL-QA',extras:Object.keys(body.extras).filter(k=>body.extras[k]),status:'awaiting_payment',amount:(body.items.reduce((n,i)=>n+prices[i.service]*i.quantity,0)+(body.extras.reiki?11:0))*100};
 await route.fulfill({json:order});
});
async function choose(service){await page.evaluate(service=>document.querySelector(`#readings a[data-service="${service}"]`).click(),service);}
async function details(){await page.locator('#clientName').fill('Local checkout QA');await page.locator('#clientEmail').fill('qa@example.invalid');}
for(const [service,total] of [['quick',1500],['rebby',2900],['live20',2500],['chart',2500]]){
 await page.goto('http://localhost:8889/');assert.equal(await page.locator('#emptyBooking').isVisible(),true);assert.equal(await page.locator('#bookingSuccessBox').isVisible(),false);
 await choose(service);await details();
 assert.equal(await page.locator('#bookingForm').evaluate(f=>f.checkValidity()),false);
 await page.locator('#clientQuestions').fill('A question associated with '+service);
 if(service==='live20'){const d=new Date();d.setDate(d.getDate()+3);await page.locator('#liveDate').fill(d.toISOString().slice(0,10));await page.locator('#liveDate').dispatchEvent('change');await page.locator('#liveSlot').selectOption({index:1});}
 if(service==='chart'){await page.locator('#chartDob').fill('1990-07-15');await page.locator('#chartTime').fill('12:30');await page.locator('#chartLocation').fill('Leeds, UK');}
 await page.locator('#submitBookingBtn').click();await page.locator('#bookingSuccessBox').waitFor({state:'visible'});
 assert.equal(order.amount,total);assert.equal(order.items[0].service,service);assert.equal(order.status,'awaiting_payment');
 const before=posts;await page.reload();await page.locator('#bookingSuccessBox').waitFor({state:'visible'});assert.equal(posts,before);assert.equal(await page.locator('#successTotalAmount').textContent(),'£'+total/100);
 await page.locator('#resetBookingBtn').click();
}
await choose('quick');await details();await page.locator('#clientQuestions').fill('First question');await page.locator('#addBasketItem').click();
await choose('rebby');await page.locator('#clientQuestions').fill('Second question');await page.locator('#extraReiki').check();
fail=true;await page.locator('#submitBookingBtn').click();await page.locator('#bookingErrorMsg').waitFor({state:'visible'});assert.equal(await page.locator('#basketItems .basket-row').count(),2);
fail=false;await page.locator('#submitBookingBtn').click();await page.locator('#bookingSuccessBox').waitFor({state:'visible'});assert.equal(order.items.length,2);assert.equal(order.amount,5500);assert.equal(order.items[0].details.questions,'First question');assert.equal(order.items[1].details.questions,'Second question');
await page.reload();await page.locator('#bookingSuccessBox').waitFor({state:'visible'});assert.equal(await page.locator('#successTotalAmount').textContent(),'£55');
for(const width of [375,390,430,768,1440]){await page.setViewportSize({width,height:900});assert.equal(await page.evaluate(()=>document.documentElement.scrollWidth>innerWidth),false);}
for(const file of ['sample-reading.pdf','tarot-cheat-sheet.pdf']){const response=await page.request.get('http://localhost:8889/'+file);assert.equal(response.status(),200);assert.equal((await response.body()).subarray(0,5).toString(),'%PDF-');}
await page.screenshot({path:'/tmp/rebby-checkout-mobile.png',fullPage:true});await browser.close();console.log('PASS: mocked £15/£29/live/chart orders, invalid forms, refresh without POST, multi-item questions and £55 extras total, failure retry without duplicates, five checkout widths and both PDF downloads. Real Stripe payment not tested.');
