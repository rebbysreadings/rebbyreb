import {chromium} from '@playwright/test';
import assert from 'node:assert/strict';
const browser=await chromium.launch();const page=await browser.newPage();
await page.route('**/api/stripe-checkout',route=>route.fulfill({json:{enabled:true,testMode:true}}));
for(const [status,testMode,expected] of [['pending',false,/not yet confirmed/],['failed',false,/payment failed/i],['paid',true,/Test checkout only/],['paid',false,/payment is confirmed/]]){
 await page.route('**/api/stripe-status?*',route=>route.fulfill({json:{status,testMode,reference:'RR-LOCAL-QA'}}));
 await page.goto('http://localhost:8889/?checkout=success&session_id=cs_test_local&case='+status+'-'+testMode+'#book');
 await page.waitForFunction(()=>!document.querySelector('.checkout-return-notice strong').textContent.includes('Checking'));
 assert.match(await page.locator('.checkout-return-notice').textContent(),expected);
 assert.equal(await page.locator('.checkout-return-notice.is-success').count(),status==='paid'&&!testMode?1:0);
 await page.unroute('**/api/stripe-status?*');
}
await browser.close();console.log('PASS: mocked pending, failed, test-paid and verified-paid return states; only verified live payment displays payment confirmation. No real payment performed.');
