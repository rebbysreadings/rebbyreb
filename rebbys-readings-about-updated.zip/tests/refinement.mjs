import {chromium} from '@playwright/test';
import assert from 'node:assert/strict';
const browser=await chromium.launch();
const nojs=await browser.newPage({javaScriptEnabled:false,viewport:{width:390,height:844}});
await nojs.goto('http://localhost:8889/free-resources/');
assert.equal(await nojs.locator('#meaningsGrid .meaning-card').count(),78);
assert.equal(await nojs.locator('#meaning-the-fool').isVisible(),true);
assert.equal(await nojs.locator('#unlockWall,.resource-signup-gate').count(),0);
await nojs.goto('http://localhost:8889/free-resources/a-simple-new-moon-intention-ritual/');
assert.equal(await nojs.locator('.blog-copy').isVisible(),true);
assert.equal(await nojs.locator('.resource-signup-gate').count(),0);
await nojs.close();
const page=await browser.newPage();const errors=[];page.on('pageerror',error=>errors.push(error.message));
await page.route('**/api/stripe-checkout',route=>route.fulfill({json:{enabled:false}}));
await page.goto('http://localhost:8889/');
assert.equal(await page.locator('#wheelOverlay').count(),0);
assert.equal(await page.locator('.testimonial').count(),8);
assert.equal(await page.locator('.testimonial:visible').count(),4);
await page.locator('.more-reviews summary').click();assert.equal(await page.locator('.testimonial:visible').count(),8);
assert.equal(await page.locator('[data-card-method]:visible').count(),0);
await page.evaluate(()=>document.querySelector('#readings a[data-service=quick]').click());
assert.equal(await page.locator('#serviceSelect').inputValue(),'quick');
assert.match(await page.locator('#deliveryComparison').textContent(),/Standard.*7 days.*Priority.*£15.*48–72/s);
assert.equal(await page.locator('#contact a[href="mailto:rebbysreadings@gmail.com"]').isVisible(),true);
for(const width of [375,390,430,768,1440]){
 await page.setViewportSize({width,height:900});
 assert.equal(await page.evaluate(()=>document.documentElement.scrollWidth>innerWidth),false,'Homepage overflow '+width);
}
await page.setViewportSize({width:1440,height:1000});await page.locator('#about').scrollIntoViewIfNeeded();await page.screenshot({path:'/tmp/rebby-about-desktop.png'});
await page.setViewportSize({width:390,height:844});await page.locator('#contact').scrollIntoViewIfNeeded();await page.screenshot({path:'/tmp/rebby-contact-mobile.png'});
await page.goto('http://localhost:8889/free-resources/');await page.locator('#cardCategory').selectOption('Cups');assert.equal(await page.locator('.meaning-card:visible').count(),14);
await page.locator('#cardSearch').fill('Ace of Cups');assert.equal(await page.locator('.meaning-card:visible').count(),1);
await page.locator('#cardSearch').fill('zzzznomatch');assert.match(await page.locator('#cardSearchCount').textContent(),/No cards match/);
await page.locator('#cardSearch').fill('');await page.locator('#cardCategory').selectOption('all');assert.equal(await page.locator('.meaning-card:visible').count(),78);
for(const width of [375,390,430,768,1440]){await page.setViewportSize({width,height:900});assert.equal(await page.evaluate(()=>document.documentElement.scrollWidth>innerWidth),false,'Library overflow '+width);}
assert.deepEqual(errors,[]);await browser.close();console.log('PASS: ungated library without JavaScript, card search and suits, eight existing reviews, no wheel, honest payment badges, preselected service, delivery comparison, contact links and five viewport widths.');
