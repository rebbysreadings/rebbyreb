import assert from 'node:assert/strict';
import bookings from '../netlify/functions/bookings.mts';
import webhook from '../netlify/functions/stripe-webhook.mts';
import manage from '../netlify/functions/manage-orders.mts';
Object.assign(globalThis,{Netlify:{env:{get:()=>undefined}}});
const base={name:'Validation check',email:'check@example.org',token:crypto.randomUUID(),items:[{service:'rebby',quantity:1,details:{questions:'A validation check'}}],extras:{}};
async function check(body:unknown,expected:number){const response=await bookings(new Request('https://example.org/api/bookings',{method:'POST',headers:{origin:'https://example.org','Content-Type':'application/json'},body:JSON.stringify(body)}));assert.equal(response.status,expected);}
await check({...base,name:''},400);
await check({...base,items:[{service:'toString',quantity:1,details:{questions:'Check'}}]},400);
await check({...base,items:[{service:'live60',quantity:1,details:{questions:'Check',live_date:'2020-01-01',live_slot:'09:00 am'}}]},400);
await check({...base,items:[{service:'chart',quantity:1,details:{questions:'Check',birth_date:'1990-01-01',birth_location:'Leeds'}}]},400);
await check({...base,items:[{service:'jar',quantity:1,details:{questions:'Check'}}]},400);
await check({...base,extras:{invented:true}},400);
assert.equal((await bookings(new Request('https://example.org/api/bookings',{method:'POST',body:'{}'}))).status,403);
assert.equal((await webhook(new Request('https://example.org/api/stripe-webhook',{method:'POST',body:'{}'}))).status,503);
assert.equal((await manage(new Request('https://example.org/api/manage-orders'))).status,503);
console.log('PASS: invalid input, prototype service name, past appointment, missing birth time/address, invalid extras, cross-origin rejection, and unconfigured webhook/admin fail closed.');
