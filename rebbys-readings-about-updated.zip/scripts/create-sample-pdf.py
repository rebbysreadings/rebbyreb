"""Generate the public sample reading. Requires reportlab and Pillow."""
from pathlib import Path
from reportlab.pdfgen import canvas
from reportlab.lib.colors import HexColor
from reportlab.lib.utils import ImageReader
from reportlab.platypus import Paragraph
from reportlab.lib.styles import ParagraphStyle
from reportlab.pdfbase import pdfmetrics
from reportlab.pdfbase.ttfonts import TTFont

ROOT = Path(__file__).resolve().parents[1]
PUBLIC = ROOT / 'public'
FONT = Path('/usr/share/fonts/truetype/dejavu')
for name, file in [('Body','DejaVuSans.ttf'),('Display','DejaVuSerif.ttf'),('Italic','DejaVuSerif.ttf')]:
    pdfmetrics.registerFont(TTFont(name, str(FONT / file)))
W,H=595.28,841.89
cream='#fbf8f3'; plum='#4a335a'; gold='#9f814b'; muted='#6e6177'
c=canvas.Canvas(str(PUBLIC/'sample-reading.pdf'),pagesize=(W,H))
c.setTitle("A little clarity | Rebby's Readings — sample reading")
c.setAuthor("Rebby's Readings")
def text(value,x,y,size=11,font='Body',colour=plum):
    c.setFillColor(HexColor(colour)); c.setFont(font,size); c.drawString(x,y,value)
def para(value,y,size=11,leading=19,width=483):
    st=ParagraphStyle('reading',fontName='Body',fontSize=size,leading=leading,textColor=HexColor(plum))
    p=Paragraph(value,st); _,h=p.wrap(width,H); p.drawOn(c,56,y-h); return y-h

def page(n,section):
    c.setFillColor(HexColor(cream)); c.rect(0,0,W,H,fill=1,stroke=0)
    c.setStrokeColor(HexColor(gold)); c.setLineWidth(.6); c.rect(28,28,W-56,H-56)
    text("REBBY’S READINGS",56,785,9,colour=gold)
    text(section,56,763,9,colour=muted)
    c.line(56,746,W-56,746)
    text('ILLUSTRATIVE SAMPLE · NOT A CLIENT READING',56,48,7,colour=muted)
    text(f'{n} / 4',505,48,8,colour=gold)
def title(kicker,heading):
    text(kicker.upper(),56,706,9,colour=gold); text(heading,56,665,28,'Display')
def card(slug,x,y,w):
    from PIL import Image
    with Image.open(PUBLIC/'cards'/f'{slug}.jpg') as im:
        h=w*im.height/im.width
    c.drawImage(str(PUBLIC/'cards'/f'{slug}.jpg'),x,y,width=w,height=h, preserveAspectRatio=True,mask='auto')

page(1,'A keepsake, written with care')
c.drawImage(str(PUBLIC/'rebbys-logo-dark.png'),133,585,width=330,height=125,preserveAspectRatio=True,anchor='c',mask='auto')
text('A little clarity',120,535,38,'Display')
text('An example of your written tarot reading',94,499,14,'Italic')
for slug,x in [('the-star',105),('eight-of-pentacles',248),('queen-of-cups',391)]: card(slug,x,260,100)
para('A thoughtful question. Three cards. Space to find your own way forward.',220,12,21)
para('Inside: your question and spread, individual card interpretations, a closing message and reflection prompts.',157,10,18)
text('EXAMPLE ONLY · YOUR READING IS PERSONAL TO YOU',56,86,8,colour=gold)
c.showPage()
page(2,'01 / Your question & the cards')
title('The starting point','Room for a new chapter')
y=para('This fictional example explores a change in working life. It shows the tone and structure of a three-card written reading; other services have their own depth and format.',628)
y=para('“How can I approach a new creative direction with more confidence?”',y-28,15,25)
y=para('We are looking at what supports you, what asks for your attention and what you can carry forward. Take what feels useful and leave yourself room to choose.',y-25)
for slug,x in [('the-star',66),('eight-of-pentacles',240),('queen-of-cups',414)]: card(slug,x,226,110)
for x,num,label,name in [(56,'01','What supports you','The Star'),(230,'02','Your next step','Eight of Pentacles'),(404,'03','What to carry forward','Queen of Cups')]:
    text(num,x,204,9,colour=gold); text(label,x,182,9);text(name,x,161,10,'Display')
para('All three cards are upright in this example. Read the spread as an invitation to reflect, rather than a fixed prediction of what must happen.',121,9,16)
c.showPage()
page(3,'02 / Your interpretation')
title('Reading the story','Hope, practice & self-trust')
y=625
for kicker,heading,body in [
('01 / THE STAR','Let hope have a place','The Star suggests a quieter return to confidence. You may be waiting until you feel completely ready before allowing yourself to begin. This card invites you to make room for the possibility that your interest matters, even while the outcome is uncertain. Notice which part of this creative direction leaves you feeling more like yourself.'),
('02 / EIGHT OF PENTACLES','Build trust through practice','The Eight of Pentacles brings the focus back to small, repeatable steps. Confidence may grow from doing the work rather than thinking your way past every doubt. Choose one skill to practise, one piece to finish or one person whose feedback you trust. A manageable routine gives your hope somewhere practical to land.'),
('03 / QUEEN OF CUPS','Stay in conversation with yourself','The Queen of Cups invites kindness towards your emotional experience. Excitement and nervousness can exist together. Before you agree to a new commitment, give yourself time to notice how it feels and what support you need. Listening to yourself can sit alongside clear boundaries, sensible planning and advice from people you trust.')]:
    text(kicker,56,y,9,colour=gold);text(heading,56,y-29,19,'Display');y=para(body,y-47,10.5,18)-32
c.showPage()
page(4,'03 / Bring it into everyday life')
title('Your closing message','Begin gently. Keep going.')
y=para('Together, these cards suggest that hope needs both care and a little structure. You do not need to decide your whole future today. A small, honest step can help you learn what this direction means to you.',625)
y=para('For the coming week: set aside one realistic block of time for your creative idea. Afterwards, note what gave you energy, what felt difficult and what you would like to try next.',y-20)
text('A few questions to sit with',56,y-44,19,'Display')
y-=72
for q in ['What would I try if I allowed myself to be a beginner?', 'What small action is within my control this week?', 'What support or boundary would help me feel steadier?']:
    y=para(q,y,10.5,18)-10
    c.setStrokeColor(HexColor('#e1d5d9'));c.line(56,y-12,539,y-12);y-=38
text('With care, Rebby',56,y-5,19,'Italic')
para('About this sample: this is an illustrative reading created to show the presentation and tone of a written PDF. It is not a real client report or a personal prediction. Your cards, questions and report length depend on your chosen service.',y-33,8,13)
para('Tarot offers reflection and personal insight. You remain in charge of your choices; a reading does not replace professional medical, legal or financial advice.',104,8,13)
c.save()
