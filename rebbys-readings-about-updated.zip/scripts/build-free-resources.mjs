// WARNING: public/free-resources/ now matches the newer site at relaxed-cranachan-afe143.netlify.app
// (public card meanings, search, and optional newsletter form). Running this script overwrites those pages
// with the older ungated versions, so only run it if you mean to regenerate them from scratch.
// Copies the Free Resources library onto this site.
// Run: node scripts/build-free-resources.mjs
// Fetches every guide from the source library, saves images locally, and
// writes branded article pages + a library index under public/free-resources/.
import { mkdir, writeFile } from 'node:fs/promises';
import { dirname, join } from 'node:path';
import { fileURLToPath } from 'node:url';

const SRC = 'https://agent-6aeb8fccb4bf7cccbe--dazzling-longma-f54ebc.netlify.app';
const SITE = 'https://rebbysreadings.com';
const OUT = join(dirname(fileURLToPath(import.meta.url)), '..', 'public', 'free-resources');

const esc = s => s.replace(/&/g, '&amp;').replace(/</g, '&lt;');

async function getText(url) {
  const res = await fetch(url);
  if (!res.ok) throw new Error(`GET ${url} -> ${res.status}`);
  return res.text();
}
async function getBin(url) {
  const res = await fetch(url);
  if (!res.ok) throw new Error(`GET ${url} -> ${res.status}`);
  return Buffer.from(await res.arrayBuffer());
}

const SHARED_CSS = `
:root{--cream:#fbf8f3;--white:#fff;--ink:#2b2033;--plum:#4a335a;--gold:#bfa168;--gold-dark:#9f814b;--border:#e8dff0;--muted:#6e6177;--lilac:#f3eefa;--serif:"Cormorant Garamond",Georgia,serif;--body:"EB Garamond",Georgia,serif}
*,*::before,*::after{box-sizing:border-box}
body{margin:0;background:var(--cream);color:var(--ink);font-family:var(--body);font-size:19px;line-height:1.65;-webkit-font-smoothing:antialiased}
img{max-width:100%;height:auto;display:block}
a{color:var(--plum);text-underline-offset:3px}
.wrap{width:min(1140px,calc(100% - 2.5rem));margin-inline:auto}
.top{display:flex;align-items:center;justify-content:space-between;gap:1rem;padding:1rem 0;flex-wrap:wrap}
.top img{height:64px;width:auto}
.top nav{display:flex;gap:1.1rem;flex-wrap:wrap;font-size:1.05rem}
h1,h2,h3{font-family:var(--serif);font-weight:500;line-height:1.15;margin:0 0 .5em}
.blog-breadcrumb{font-size:.95rem;color:var(--muted);margin:1.4rem 0 0}
.blog-article{max-width:46rem;margin:1rem auto 0}
.hero-badge{display:inline-block;background:var(--lilac);border:1px solid var(--border);color:var(--plum);border-radius:999px;padding:.25rem 1rem;font-size:.95rem;margin-bottom:.9rem}
.blog-article h1{font-size:clamp(2.2rem,6vw,3.4rem)}
.blog-intro{font-size:1.3rem;color:#43374c}
.blog-byline{color:var(--muted);font-size:1rem;border-bottom:1px solid var(--border);padding-bottom:1.2rem}
.blog-cover{border-radius:20px;margin:1.6rem 0;box-shadow:0 14px 34px -10px rgba(74,51,90,.18)}
.blog-copy h2{font-size:1.9rem;margin-top:2.2rem}
.blog-note{background:var(--lilac);border-left:4px solid var(--gold);border-radius:0 12px 12px 0;padding:1rem 1.2rem;margin-top:2rem;font-style:italic}
.related-resources{max-width:60rem;margin:3rem auto 0}
.related-grid{display:grid;grid-template-columns:repeat(auto-fit,minmax(16rem,1fr));gap:1.2rem;margin:1.2rem 0 2rem}
.related-grid a{background:var(--white);border:1px solid var(--border);border-radius:16px;overflow:hidden;text-decoration:none;display:block}
.related-grid img{aspect-ratio:8/5;object-fit:cover;width:100%}
.related-grid span{display:block;padding:.9rem 1.1rem;font-family:var(--serif);font-size:1.2rem}
.btn{display:inline-flex;align-items:center;justify-content:center;min-height:50px;padding:.75rem 2rem;border-radius:999px;border:1px solid var(--plum);background:var(--plum);color:#fff;font-family:var(--serif);font-size:1.25rem;text-decoration:none;cursor:pointer}
.btn.ghost{background:transparent;color:var(--plum)}
.cta-band{background:linear-gradient(180deg,var(--lilac),var(--cream));border:1px solid var(--border);border-radius:24px;padding:2.2rem;text-align:center;max-width:46rem;margin:3rem auto 0}
.cta-band p{max-width:34rem;margin:0 auto 1.2rem}
.signup-row{display:flex;gap:.7rem;justify-content:center;flex-wrap:wrap}
.signup-row input{font:inherit;padding:.7rem 1.1rem;border:1px solid var(--border);border-radius:999px;min-width:min(16rem,100%)}
.hp{display:none!important}
.site-footer{margin-top:4rem;padding:2.5rem 0 3rem;border-top:1px solid var(--border);text-align:center;color:var(--muted);font-size:.95rem}
.sound-player{padding:1.5rem;background:var(--lilac);border-radius:16px;margin-top:2rem}
.sound-player h2{margin-top:0}
.sound-player button{font:inherit;padding:.6rem 1.3rem;border-radius:999px;border:1px solid var(--plum);background:var(--plum);color:#fff;cursor:pointer;margin:.3rem .2rem .3rem 0}
.sound-player button[aria-pressed="true"]{background:var(--gold-dark);border-color:var(--gold-dark)}
.frequency-picker{padding:1rem 0}
.frequency-picker select{width:100%;max-width:320px;padding:.7rem 1rem;border:1px solid var(--gold);border-radius:8px;background:#fffcf7;color:var(--plum);font:inherit;margin-top:.5rem;display:block}
.print-sheet{border:1px dashed var(--gold);border-radius:16px;padding:1.5rem;margin-top:1.5rem;background:#fffdf8}
[data-print]{font:inherit;padding:.6rem 1.3rem;border-radius:999px;border:1px solid var(--plum);background:transparent;color:var(--plum);cursor:pointer;margin-top:.6rem}
@media print{.top,.related-resources,.cta-band,.site-footer,[data-print]{display:none!important}.blog-article{max-width:100%}}
`;

function pageShell({ title, description, image, pathSuffix, body, extraJs = '' }) {
  return `<!doctype html>
<html lang="en-GB"><head><meta charset="utf-8"><meta name="viewport" content="width=device-width,initial-scale=1">
<title>${title} | Rebby's Readings</title>
<meta name="description" content="${description}">
<link rel="canonical" href="${SITE}/free-resources/${pathSuffix}">
<meta property="og:title" content="${title}">
<meta property="og:description" content="${description}">
<meta property="og:type" content="article">
<meta property="og:url" content="${SITE}/free-resources/${pathSuffix}">
<meta property="og:image" content="${esc(image)}">
<meta name="twitter:card" content="summary_large_image">
<link rel="icon" href="/rebbys-mark-32.png">
<link rel="preconnect" href="https://fonts.googleapis.com"><link rel="preconnect" href="https://fonts.gstatic.com" crossorigin>
<link href="https://fonts.googleapis.com/css2?family=Cormorant+Garamond:ital,wght@0,400;0,500;0,600;1,400&family=EB+Garamond:ital,wght@0,400;0,500;1,400&display=swap" rel="stylesheet">
<style>${SHARED_CSS}</style></head>
<body><div class="wrap">
<header class="top"><a href="/" aria-label="Rebby's Readings home"><img src="/rebbys-logo-dark.png" alt="Rebby's Readings"></a>
<nav aria-label="Main navigation"><a href="/#readings">Readings &amp; prices</a><a href="/free-resources/">Free resources</a><a href="/#book">Book a reading</a></nav></header>
<main id="main-content">${body}</main>
<section class="cta-band" aria-labelledby="cta-title"><h2 id="cta-title">Want guidance made just for you?</h2>
<p>These guides are a gentle starting point. A personal reading with Rebby goes deeper into your own questions.</p>
<p><a class="btn" href="/#book">Book a reading &rarr;</a> <a class="btn ghost" href="/free-resources/">Browse all free guides</a></p></section>
<footer class="site-footer"><p><a href="/">Rebby&rsquo;s Readings</a> &middot; <a href="/free-resources/">Free resources</a> &middot; <a href="https://www.facebook.com/112793701477745" target="_blank" rel="noopener">Facebook</a></p>
<p><small>Tarot and spiritual reflections are offered for personal insight and entertainment, not professional advice. Take what feels helpful and leave the rest.</small></p></footer>
</div>${extraJs ? `<script>${extraJs}</script>` : ''}</body></html>`;
}

const PLAYER_JS = `
let audioContext, source, gain;
function stopSound(){if(source){try{source.stop()}catch(e){}source.disconnect();source=null}if(gain){gain.disconnect();gain=null}
const st=document.querySelector('#soundStatus');if(st)st.textContent='Sound is stopped.';
document.querySelectorAll('[data-sound]').forEach(b=>b.setAttribute('aria-pressed','false'));}
document.querySelectorAll('[data-sound]').forEach(button=>{button.setAttribute('aria-pressed','false');
button.addEventListener('click',async()=>{try{stopSound();audioContext=audioContext||new(window.AudioContext||window.webkitAudioContext)();
await audioContext.resume();gain=audioContext.createGain();gain.gain.setValueAtTime(0,audioContext.currentTime);
gain.gain.linearRampToValueAtTime(Number(document.querySelector('#soundVolume').value),audioContext.currentTime+.15);
gain.connect(audioContext.destination);
if(button.dataset.sound==='rain'){const buf=audioContext.createBuffer(1,audioContext.sampleRate*4,audioContext.sampleRate);
const d=buf.getChannelData(0);let last=0;for(let i=0;i<d.length;i++){last=(last+(Math.random()*2-1)*.04)/1.04;d[i]=last*5}
source=audioContext.createBufferSource();source.buffer=buf;source.loop=true;}
else{source=audioContext.createOscillator();source.type='sine';source.frequency.value=Number(document.querySelector('#soundFrequency')?.value||174);}
source.connect(gain);source.start();button.setAttribute('aria-pressed','true');
const st=document.querySelector('#soundStatus');if(st)st.textContent=button.dataset.sound==='rain'?'Playing soft rain.':'Playing '+(document.querySelector('#soundFrequency')?.value||174)+' Hz.';}
catch(e){stopSound();const st=document.querySelector('#soundStatus');if(st)st.textContent='Sound is unavailable in this browser.';}});});
document.querySelector('#stopSound')?.addEventListener('click',stopSound);
document.querySelector('#soundVolume')?.addEventListener('input',e=>{if(gain)gain.gain.setTargetAtTime(Number(e.target.value),audioContext.currentTime,.03)});
document.querySelector('#soundFrequency')?.addEventListener('change',e=>{if(source?.frequency){source.frequency.setTargetAtTime(Number(e.target.value),audioContext.currentTime,.12);
const st=document.querySelector('#soundStatus');if(st)st.textContent='Playing '+e.target.value+' Hz.';}});
document.addEventListener('visibilitychange',()=>{if(document.hidden)stopSound()});
window.addEventListener('pagehide',stopSound);
document.querySelectorAll('[data-print]').forEach(button=>{button.addEventListener('click',()=>{document.querySelectorAll('.printing').forEach(s=>s.classList.remove('printing'));
button.closest('.print-sheet')?.classList.add('printing');window.print();});});
window.addEventListener('afterprint',()=>document.querySelectorAll('.printing').forEach(s=>s.classList.remove('printing')));`;

const indexHtml = await getText(`${SRC}/free-resources/`);
const catRe = /<section class="resource-category" id="([^"]+)">([\s\S]*?)<\/section>/g;
const categories = [];
let m;
while ((m = catRe.exec(indexHtml))) {
  const id = m[1], inner = m[2];
  const count = (inner.match(/<span class="count-badge">([^<]*)<\/span>/) || [])[1] || '';
  const title = (inner.match(/<h2>([^<]*)<\/h2>/) || [])[1] || id;
  const desc = (inner.match(/<\/h2>\s*<p>([\s\S]*?)<\/p>/) || [])[1] || '';
  const cards = [];
  const cardRe = /<a class="card-link" href="(\/free-resources\/([^"/]+)\/)">[\s\S]*?<img src="([^"]+)" alt="([^"]*)"[\s\S]*?<span class="read-time">([^<]*)<\/span><h3>([^<]*)<\/h3><p>([\s\S]*?)<\/p>/g;
  let c;
  while ((c = cardRe.exec(inner))) cards.push({ href: c[1], slug: c[2], img: c[3], alt: c[4], badge: c[5], title: c[6], excerpt: c[7] });
  categories.push({ id, count, title, desc, cards });
}
console.log('categories:', categories.map(c => `${c.id} (${c.cards.length})`).join(', '));

// Download images
await mkdir(join(OUT, 'images'), { recursive: true });
const seen = new Set();
for (const cat of categories) for (const card of cat.cards) {
  if (seen.has(card.img)) continue;
  seen.add(card.img);
  const file = card.img.split('/').pop();
  const bin = await getBin(`${SRC}${card.img}`);
  await writeFile(join(OUT, 'images', file), bin);
  console.log('img', file, bin.length, 'bytes');
}

// Build article pages
for (const cat of categories) for (const card of cat.cards) {
  const html = await getText(`${SRC}${card.href}`);
  const title = (html.match(/<title>([^<]*)<\/title>/) || [])[1]?.replace(/\s*\|.*$/, '') || card.title;
  const desc = (html.match(/<meta name="description" content="([^"]*)"/) || [])[1] || card.excerpt;
  const ogImg = (html.match(/<meta property="og:image" content="([^"]*)"/) || [])[1] || '';
  const main = (html.match(/<main[^>]*>([\s\S]*?)<\/main>/) || [])[1] || '';
  const image = ogImg.replace('https://rebbysreadings.com', SITE);
  const needsPlayer = main.includes('data-sound') || main.includes('data-print');
  await mkdir(join(OUT, card.slug), { recursive: true });
  await writeFile(join(OUT, card.slug, 'index.html'),
    pageShell({ title, description: desc, image, pathSuffix: `${card.slug}/`, body: main, extraJs: needsPlayer ? PLAYER_JS : '' }));
  console.log('page', card.slug);
}

// Build library index
const cardHtml = c => `<article class="resource-card"><a class="card-link" href="${c.href}"><div class="card-image"><img src="${c.img}" alt="${c.alt}" width="640" height="400" loading="lazy"></div><div class="card-content"><span class="read-time">${c.badge}</span><h3>${c.title}</h3><p>${c.excerpt}</p><span class="read-more">Read the guide &rarr;</span></div></a></article>`;
const libBody = `
<nav class="blog-breadcrumb" aria-label="Breadcrumb"><a href="/">Home</a><span aria-hidden="true"> / </span><span>Free resources</span></nav>
<header class="lib-hero"><span class="hero-badge">\u2727 Free Resources</span>
<h1>Gentle guides, <em>free to read</em></h1>
<p class="blog-intro">Tarot basics, spreads, moon rituals, self-love, printables and calming sounds from Rebby. Pour a cup of tea and explore all ${categories.reduce((n, c) => n + c.cards.length, 0)} guides below.</p></header>
<nav class="lib-pills" aria-label="Resource categories"><ul>${categories.map(c => `<li><a href="#${c.id}">${c.title}</a></li>`).join('')}</ul></nav>
${categories.map(c => `<section class="resource-category" id="${c.id}" aria-labelledby="${c.id}-h"><span class="hero-badge">${c.count}</span><h2 id="${c.id}-h">${c.title}</h2><p class="cat-desc">${c.desc}</p><div class="resource-grid">${c.cards.map(cardHtml).join('')}</div></section>`).join('')}
<section class="cta-band" aria-labelledby="lib-cta"><h2 id="lib-cta">Get new guides &amp; gentle offers by email</h2>
<p>Join Rebby&rsquo;s circle for tarot news, new free guides and the occasional treat. Unsubscribe at any time by emailing rebbysreadings@gmail.com. All resources are free without signup.</p>
<form id="circleForm" name="circle-signup" method="POST" data-netlify="true" netlify-honeypot="bot-field">
<input type="hidden" name="form-name" value="circle-signup">
<p class="hp" hidden aria-hidden="true"><label>Leave empty: <input type="text" name="bot-field" tabindex="-1" autocomplete="off"></label></p>
<div class="signup-row"><input type="text" name="name" aria-label="Your first name" placeholder="Your first name" autocomplete="given-name" required>
<input type="email" name="email" aria-label="Your email address" placeholder="you@example.com" autocomplete="email" required>
<button class="btn" type="submit">Join the circle &rarr;</button></div>
<p id="circleStatus" role="status" aria-live="polite"></p></form></section>`;

const LIB_CSS = `
.lib-hero{max-width:46rem;margin:1rem auto 0;text-align:center}
.lib-hero h1{font-size:clamp(2.4rem,6vw,3.8rem)}
.lib-hero h1 em{font-style:italic;color:var(--plum)}
.lib-pills ul{display:flex;gap:.6rem;justify-content:center;flex-wrap:wrap;list-style:none;margin:1.6rem 0 0;padding:0}
.lib-pills a{display:inline-block;border:1px solid var(--border);background:var(--white);border-radius:999px;padding:.4rem 1.1rem;text-decoration:none;font-size:1rem}
.resource-category{max-width:70rem;margin:3rem auto 0}
.cat-desc{color:#43374c;max-width:40rem}
.resource-grid{display:grid;grid-template-columns:repeat(auto-fill,minmax(17rem,1fr));gap:1.2rem;margin-top:1.4rem}
.resource-card{background:var(--white);border:1px solid var(--border);border-radius:16px;overflow:hidden;transition:transform .25s,box-shadow .25s}
.resource-card:hover{transform:translateY(-4px);box-shadow:0 14px 34px -10px rgba(74,51,90,.18)}
.card-link{text-decoration:none;color:inherit;display:block}
.card-image img{aspect-ratio:8/5;object-fit:cover;width:100%}
.card-content{padding:1.1rem 1.2rem 1.3rem}
.read-time{font-size:.9rem;color:var(--muted)}
.card-content h3{font-size:1.35rem;margin:.3rem 0 .4rem}
.card-content p{font-size:1rem;color:#43374c;margin:0 0 .6rem}
.read-more{color:var(--plum);font-weight:600}
`;

const libHtml = pageShell({ title: 'Free Tarot Guides, Spreads, Rituals & Calming Sounds', description: 'Free tarot guides, card spreads, moon rituals, self-love practices, printable worksheets and calming sounds from Rebby. Gentle guidance, free to read.', image: `${SITE}/free-resources/images/rain.jpg`, pathSuffix: '', body: libBody })
  .replace('</style>', LIB_CSS + '</style>')
  .replace('</body>', `<script>
const f=document.querySelector('#circleForm');
f?.addEventListener('submit',async e=>{e.preventDefault();if(!f.reportValidity())return;
const s=document.querySelector('#circleStatus');s.textContent='Joining…';
try{const r=await fetch('/',{method:'POST',headers:{'Content-Type':'application/x-www-form-urlencoded'},body:new URLSearchParams(new FormData(f)).toString()});
if(!r.ok)throw 0;f.reset();s.textContent='Thank you — your newsletter request has been received.';}catch(e){s.textContent='Sorry, that did not go through. Please try again or message Rebby on Facebook.';}});</script></body>`);
await writeFile(join(OUT, 'index.html'), libHtml);
console.log('library index written');
console.log('DONE slugs:', categories.reduce((n, c) => n + c.cards.length, 0));
